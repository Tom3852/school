Given the list from the main migration status page:
1.	Using Azure DevOps for CI (Done for all repos)
2.	Using shared toolset (Arcade SDK)
3.	Engineering dependency flow
4.	Internal builds from dnceng

CLI 
2.	Beginning Nov. (Under way)
3.	Mid Nov.
4.	Eng Nov.

Toolset
2.	Mid Nov (Will follow after CLI)
3.	Mid Nov
4.	Eng Nov

Core-sdk
2.	Beginning Nov. (Under way)
3.	Mid Nov.
4.	Eng Nov.

from @licavalc on 10/30
