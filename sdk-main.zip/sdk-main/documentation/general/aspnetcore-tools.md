ASP.NET Core Command Line Tools
===============================

The .NET Core CLI includes some commands that are specific to ASP.NET Core projects.

 - dotnet dev-certs
 - dotnet user-secrets
 - dotnet user-jwts
 - dotnet sql-cache

For more information on these tools, see <https://github.com/aspnet/DotNetTools>.
