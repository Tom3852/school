' Copyright (c) .NET Foundation and contributors. All rights reserved.
' Licensed under the MIT license. See LICENSE file in the project root for full license information.

Imports System

Namespace TestApp

    Module Program

        Sub Main(args As String())
            Console.WriteLine(TestLibrary.Helper.GetMessage())
        End Sub

    End Module

End Namespace
