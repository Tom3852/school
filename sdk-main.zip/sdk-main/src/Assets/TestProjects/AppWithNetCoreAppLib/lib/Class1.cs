﻿using System;

namespace classlib
{
    public class Class1
    {
    }
}
