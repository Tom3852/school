namespace TestLibrary

module Say =
    let public hello name =
        printfn "Hello %s" name
