﻿// Learn more about F# at http://fsharp.org

open System

[<EntryPoint>]
let main argv =
    TestLibrary.Say.hello "F#"
    0 // return an integer exit code
