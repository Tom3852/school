﻿using System;

namespace LibraryWithoutRid
{
    public class PortableClass
    {
        public static string GetHelloWorld()
        {
            return "Hello World";
        }
    }
}
