﻿using System;

namespace LibA
{
    public class Class1
    {
    }
}
