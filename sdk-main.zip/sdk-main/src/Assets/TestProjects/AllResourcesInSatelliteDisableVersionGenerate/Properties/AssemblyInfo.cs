// Copyright (c) .NET Foundation and contributors. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

using System.Reflection;

[assembly: AssemblyCompany("My Company")]
[assembly: AssemblyConfiguration("Debug")]
[assembly: AssemblyCopyright("Copyright © 2008 My Company")]
[assembly: AssemblyDescription("My assembly description")]
[assembly: AssemblyFileVersion("12.34.56.78")]
[assembly: AssemblyInformationalVersion("34.56.78.90")]
[assembly: AssemblyProduct("My Product Name")]
[assembly: AssemblyTitle("My assembly title")]
[assembly: AssemblyVersion("12.34")]
