
// This file is generated for platfrom: SupportedPlatforms

#if( Platform == "Windows" )
    // Quoted Windows
#else
    // NOT Quoted Windows
#endif
        
        
#if( Platform == Windows )
    // Windows
#else
    // NOT Windows
#endif

#if( Platform == "MacOS" )
    // Quoted MacOS
#else
    // NOT Quoted MacOS
#endif

#if( Platform == MacOS )
    // MacOS
#else
    // NOT MacOS
#endif

#if( Platform == "iOS" )
    // Quoted iOS
#else
    // NOT Quoted iOS
#endif

#if( Platform == iOS )
    // iOS
#else
    // NOT iOS
#endif
