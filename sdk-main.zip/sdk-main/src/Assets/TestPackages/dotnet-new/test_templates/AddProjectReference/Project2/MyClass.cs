﻿using System;

namespace Project2
{
    public class MyClass
    {
        public static void SayHello()
        {
            Console.WriteLine("Hello World from MyClass");
        }
    }
}
