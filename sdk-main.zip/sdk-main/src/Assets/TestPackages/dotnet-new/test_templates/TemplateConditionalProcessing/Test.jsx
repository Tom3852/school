const myElement = (
    <div>
        {/*#if defaultTrue
        <p>DefaultTrueIncluded</p>
        #else
        <p>DefaultTrueExcluded</p>
        #endif*/}
        {/*#if defaultFalse
        <p>DefaultFalseExcluded</p>
        #else
        <p>DefaultFalseIncluded</p>
        #endif*/}
      <p>I am a paragraph.</p>
    </div>
  );