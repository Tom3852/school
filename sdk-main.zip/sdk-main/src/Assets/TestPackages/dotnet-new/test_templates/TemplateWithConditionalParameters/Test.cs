
// value of paramA: placeholderA
// value of paramB: placeholderB

//#if( paramA )
	// A is enabled
//#endif

//#if( paramB )
	// B is enabled
//#endif
