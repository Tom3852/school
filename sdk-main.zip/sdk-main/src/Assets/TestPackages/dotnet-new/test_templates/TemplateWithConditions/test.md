﻿<!--#if (A) -->
<!-- comment foo -->
foo
<!--#endif -->
<!--#if (B)
<!-- comment bar -- >
bar
#endif -->
baz
