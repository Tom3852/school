using System;
using System.Collections.Generic;
using System.Text;

namespace Microsoft.TemplateEngine.EndToEndTestHarness.test_templates.TemplateWithRenames
{
    class MyProject1
    {
    }
}
