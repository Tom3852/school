using System;

namespace Microsoft.TemplateEngine.EndToEndTestHarness.test_templates.DefaultIfOptionWithoutValue
{
    public class Program
    {
        // User specified comment: OriginalString
        public void Main()
        {
            Console.WriteLine("Template created with MyChoice = OriginalChoice");
        }
    }
}
