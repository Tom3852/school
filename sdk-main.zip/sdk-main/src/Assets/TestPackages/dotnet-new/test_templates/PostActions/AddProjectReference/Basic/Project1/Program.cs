﻿using System;
using Project2;

namespace Project1
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            MyClass.SayHello();
        }
    }
}
