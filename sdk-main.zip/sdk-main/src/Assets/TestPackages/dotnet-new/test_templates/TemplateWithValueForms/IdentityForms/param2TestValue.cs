namespace Test
{
    class ContentReplacementTest
    {
        private string param2TestValue;
    }
}
