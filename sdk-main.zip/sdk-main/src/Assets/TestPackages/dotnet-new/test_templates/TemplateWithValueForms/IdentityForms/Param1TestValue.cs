namespace Test
{
    class ContentReplacementTest
    {
        private string Param1TestValue;
    }
}
