namespace Test
{
    class ContentReplacementTest
    {
        private string param3 = "param 3 test value";
    }
}
