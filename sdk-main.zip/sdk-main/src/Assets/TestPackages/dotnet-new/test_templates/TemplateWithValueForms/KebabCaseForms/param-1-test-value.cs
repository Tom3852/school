namespace Test
{
    class ContentReplacementTest
    {
        private string param-1-test-value;
    }
}
