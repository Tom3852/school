namespace Test
{
    class ContentReplacementTest
    {
        private string param3 = "Param 3 Test Value";
    }
}
