namespace Test
{
    class ContentReplacementTest
    {
        private string Param2TestValue;
    }
}
