namespace Test
{
    class ContentReplacementTest
    {
        private string param1TestValue;
    }
}
