(function () {
  document.getElementById('pkg-transitive-dep').innerHTML = 'pkg-transitive-dep';
})()